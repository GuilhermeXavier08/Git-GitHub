const prompt = require("prompt-sync")();
let idade2 = Number(prompt("Digite a sua idade: "));
if (idade2 < 16) {
  console.log("Não pode votar, e não pode tirar CNH!");
} else if (idade2 <= 17) {
  console.log("Voto opcional, e não tirar CNH!");
} else {
  console.log("Voto obrigatório, e pode tirar CNH!");
}
const prompt = require("prompt-sync")();
let contagem = 10;
while (contagem != 0) {
  console.log(contagem);
  contagem -= 1;
}
console.log("Feliz Ano Novo !!!");
nome = "Guilherme";
idade = 16;
altura = 1.75;
programador = false;
console.log(`${nome} ${idade} ${altura} ${programador}`);
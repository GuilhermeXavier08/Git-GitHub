const prompt = require("prompt-sync")();
function boasVindas(nome) {
  return console.log(`Olá, ${nome}! Sejá bem-vindo(a)`);
}
let nome2 = String(prompt("Digite seu nome: "));
console.log(boasVindas(nome2));
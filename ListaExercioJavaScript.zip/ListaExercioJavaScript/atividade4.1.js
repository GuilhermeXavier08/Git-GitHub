const prompt = require("prompt-sync")();
let i;

for (i = 1; i < 11; i++) {
  console.log(i);
}
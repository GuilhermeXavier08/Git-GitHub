const prompt = require("prompt-sync")();
let numeroAleatorio = Math.floor(Math.random() * 10) + 1;
let numeroUsuario = Number(prompt("Tente adivinhar o número entre 1 e 10:"));

if (numeroUsuario === numeroAleatorio) {
  console.log("Você acertou!");
} else {
  console.log(`Você errou! O número correto era ${numeroAleatorio}.`);
}
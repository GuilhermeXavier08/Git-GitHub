const prompt = require("prompt-sync")();
let peso2 = Number(prompt("Digite seu peso (kg):"));
let altura2 = Number(prompt("Digite sua altura (m):"));

let imc = peso2 / (altura2 * altura2);

console.log(imc);


if (imc < 18.5) {
  console.log("Abaixo do peso");
} else if (imc < 25) {
  console.log("Peso normal");
} else if (imc < 30) {
  console.log("Sobrepeso");
} else {
  console.log("Obesidade");
}
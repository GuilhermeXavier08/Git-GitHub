let AnoNascimento = 2008;
let AnoNascimentoStr = String(AnoNascimento);
console.log(AnoNascimentoStr, typeof AnoNascimentoStr);

let peso = "80.5";
let pesoNum = Number(peso);
console.log(pesoNum, typeof pesoNum);
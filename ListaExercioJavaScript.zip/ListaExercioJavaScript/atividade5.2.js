const prompt = require("prompt-sync")();
function calculadora(num1, num2, operacao) {
  switch (operacao) {
    case "+":
      return num1 + num2;
    case "-":
      return num1 - num2;
    case "*":
      return num1 * num2;
    case "/":
      return num2 !== 0 ? num1 / num2 : "Erro: divisão por zero";
    default:
      return "Operação inválida";
  }
}

let numero3 = Number(prompt("Digite o primeiro número: "));
let numero4 = Number(prompt("Digite o segundo número: "));
let operacoes = prompt("Digite um operador (+, -, *, /)");

console.log(calculadora(numero3, numero4, operacoes));
const prompt = require("prompt-sync")();
function calcularMedia(nota1, nota2, nota3) {
  let media = (nota1 + nota2 + nota3) / 3;
  return media >= 7 ? "Aprovado" : "Reprovado";
}
let nota1 = Number(prompt("Digite a primeria nota: "));
let nota2 = Number(prompt("Digite a segunda nota: "));
let nota3 = Number(prompt("Digite a terceira nota: "));

console.log(calcularMedia(nota1, nota2, nota3));
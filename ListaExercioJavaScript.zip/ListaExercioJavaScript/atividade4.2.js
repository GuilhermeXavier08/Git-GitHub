const prompt = require("prompt-sync")();
let j;
let numero2 = Number(
  prompt("Digite um número e eu mostrarei a tabuada dele: ")
);
let resultado = 0;
for (j = 1; j < 11; j++) {
  resultado += numero2;
  console.log(`${numero2} x ${j} = ${resultado}`);
}
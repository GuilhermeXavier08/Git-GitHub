const prompt = require("prompt-sync")();
let num1 = Number(prompt("Informe o primeiro número: "));
let num2 = Number(prompt("Informe o segundo número: "));

let soma = num1 + num2;
let sub = num1 - num2;
let mult = num1 * num2;
let div = num1 / num2;

console.log(`A soma dos números ${num1} e ${num2} é ${soma}`);
console.log(`A subtração dos números ${num1} e ${num2} é ${sub}`);
console.log(`A multiplicação dos números ${num1} e ${num2} é ${mult}`);
if (num2 > 0) {
  console.log(`A divisão dos números ${num1} e ${num2} é ${div}`);
} else {
  console.log("Não dividirás por zero!");
}
var prompt = require('prompt-sync');
// 1. Funções Matemáticas

// Exercício 1.1
console.log(Math.floor(Math.random() * 100) + 1);

// Exercício 1.2
function raizQuadrada(num) {
    return Math.sqrt(num);
}
const numeroRaiz = parseFloat(prompt("Digite um número para calcular a raiz quadrada:"));
console.log(`A raiz quadrada de ${numeroRaiz} é ${raizQuadrada(numeroRaiz)}`);

// Exercício 1.3
function maiorNumero(a, b) {
    return Math.max(a, b);
}
const num1 = parseFloat(prompt("Digite o primeiro número:"));
const num2 = parseFloat(prompt("Digite o segundo número:"));
console.log(`O maior número entre ${num1} e ${num2} é ${maiorNumero(num1, num2)}`);

// Exercício 1.4
const numero = parseFloat(prompt("Insira um número decimal:"));
console.log(Math.ceil(numero));
console.log(Math.floor(numero));
console.log(Math.round(numero));

// 2. Manipulação de Datas e Horas

// Exercício 2.1
const agora = new Date();
console.log(`Hoje é ${agora.toLocaleDateString()} e agora são ${agora.toLocaleTimeString()}`);

// Exercício 2.2
const nascimento = new Date(prompt("Digite sua data de nascimento (aaaa-mm-dd):"));
const idade = new Date().getFullYear() - nascimento.getFullYear();
console.log(`Você tem ${idade} anos.`);

// Exercício 2.3
function diaDaSemana(data) {
    const dias = ["Domingo", "Segunda-feira", "Terça-feira", "Quarta-feira", "Quinta-feira", "Sexta-feira", "Sábado"];
    return dias[new Date(data).getDay()];
}
const dataUsuario = prompt("Digite uma data (aaaa-mm-dd):");
console.log(`O dia da semana correspondente é ${diaDaSemana(dataUsuario)}`);

// Exercício 2.4
const natal = new Date(new Date().getFullYear(), 11, 25);
const diasParaNatal = Math.ceil((natal - new Date()) / (1000 * 60 * 60 * 24));
console.log(`Faltam ${diasParaNatal} dias para o Natal.`);

// Exercício 2.5
function diferencaEmDias(data1, data2) {
    const umDia = 1000 * 60 * 60 * 24;
    return Math.abs(Math.ceil((new Date(data1) - new Date(data2)) / umDia));
}
const data1 = prompt("Digite a primeira data (aaaa-mm-dd):");
const data2 = prompt("Digite a segunda data (aaaa-mm-dd):");
console.log(`A diferença entre as datas é de ${diferencaEmDias(data1, data2)} dias.`);

// 3. Manipulação de Strings

// Exercício 3.1
const nome = prompt("Digite seu nome:");
console.log(nome.length);

// Exercício 3.2
function fraseMaiuscula(frase) {
    return frase.toUpperCase();
}
const fraseUsuario = prompt("Digite uma frase:");
console.log(fraseMaiuscula(fraseUsuario));

// Exercício 3.3
const frase = prompt("Digite uma frase:");
console.log(frase.replace(/JavaScript/g, "JS"));

// Exercício 3.4
function primeiroNome(nomeCompleto) {
    return nomeCompleto.split(" ")[0];
}
const nomeCompletoUsuario = prompt("Digite seu nome completo:");
console.log(`Seu primeiro nome é: ${primeiroNome(nomeCompletoUsuario)}`);

// Exercício 3.5
const texto = prompt("Digite um texto com vírgulas:");
console.log(texto.split(","));

// Exercício 3.6
function validarEmail(email) {
    return email.includes("@") && email.includes(".");
}
const emailUsuario = prompt("Digite seu e-mail:");
console.log(`O e-mail é válido? ${validarEmail(emailUsuario)}`);

// 4. Aplicações Práticas

// Exercício 4.1
const participantes = ["Ana", "Bruno", "Carlos", "Daniel", "Eduarda", "Fernanda", "Gustavo", "Helena", "Igor", "Juliana"];
const vencedor = participantes[Math.floor(Math.random() * participantes.length)];
console.log(`O vencedor é ${vencedor}.`);

// Exercício 4.2
const vencimento = new Date(prompt("Digite a data de vencimento (aaaa-mm-dd):"));
const diferenca = Math.ceil((vencimento - new Date()) / (1000 * 60 * 60 * 24));
if (diferenca > 0) {
    console.log(`Faltam ${diferenca} dias para o vencimento.`);
} else {
    console.log(`A conta venceu há ${Math.abs(diferenca)} dias.`);
}

// Exercício 4.3
function limparCPF(cpf) {
    return cpf.replace(/\D/g, "");
}
const cpfUsuario = prompt("Digite seu CPF:");
console.log(`CPF limpo: ${limparCPF(cpfUsuario)}`);

// Exercício 4.4
const evento = prompt("Digite o nome do evento:");
const dataEvento = new Date(prompt("Digite a data do evento (aaaa-mm-dd):"));
const diasParaEvento = Math.ceil((dataEvento - new Date()) / (1000 * 60 * 60 * 24));
console.log(`Faltam ${diasParaEvento} dias para o evento '${evento}'.`);

// Exercício 4.5
const numeroAleatorio = Math.floor(Math.random() * 50) + 1;
let tentativa;
do {
    tentativa = parseInt(prompt("Adivinhe o número entre 1 e 50:"));
    if (tentativa > numeroAleatorio) {
        console.log("Muito alto");
    } else if (tentativa < numeroAleatorio) {
        console.log("Muito baixo");
    }
} while (tentativa !== numeroAleatorio);
console.log("Parabéns! Você acertou.");